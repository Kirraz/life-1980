/*
*    FORMAT:
*        STRING (Conditions) - Must return boolean :
*            String can contain any amount of conditions, aslong as the entire
*            string returns a boolean. This allows you to check any levels, licenses etc,
*            in any combination. For example:
*                "call life_coplevel && license_civ_someLicense"
*            This will also let you call any other function.
*
*
*    ARRAY FORMAT:
*        0: STRING (Classname): Item Classname
*        1: STRING (Nickname): Nickname that will appear purely in the shop dialog
*        2: SCALAR (Buy price)
*        3: SCALAR (Sell price): To disable selling, this should be -1
*        4: STRING (Conditions): Same as above conditions string
*
*    Weapon classnames can be found here: https://community.bistudio.com/wiki/Arma_3_CfgWeapons_Weapons
*    Item classnames can be found here: https://community.bistudio.com/wiki/Arma_3_CfgWeapons_Items
*
*/
class WeaponShops {
    //Armory Shops
    class gun {
        name = "Billy Joe's Firearms";
        side = "civ";
        conditions = "license_civ_gun";
        items[] = {
            { "vn_m127", "", 2500, 1250, "" }, //pf
			{ "vn_m1895", "", 6500, 3250, "" }, //pf
			{ "vn_p38s", "", 6500, 3250, "" }, //pf
            { "vn_pm", "", 7000, 3500, "" }, //pf
            { "vn_m712", "", 9850, 4925, "" }, //pf
            { "vn_tt33", "", 11500, 5750, "" }, //pf
			{ "vn_m1911", "", 11500, 5750, "" }, //pf
            { "vn_izh54", "", 18000, 9000, "" }, //pf
            { "vn_m9130", "", 20000, 10000, "" },  //pf
			{ "vn_sks", "", 20000, 10000, "" }  //pf
        };
        mags[] = {
            { "vn_m1911_mag", "", 125, 60, "" }, //pf
			{ "vn_m127_mag", "", 1025, 60, "" }, //pf
            { "vn_pm_mag", "", 150, 75, "" }, //pf
            { "vn_tt33_mag", "", 200, 100, "" }, //pf
            { "vn_m1895_mag", "", 250, 125, "" }, //pf
            { "vn_izh54_mag", "", 250, 125, "" }, //pf
            { "vn_m38_t_mag", "", 250, 125, "" },  //pf
			{ "vn_sks_t_mag", "", 250, 125, "" }  //pf
        };
        accs[] = {
            { "acc_flashlight_pistol", "", 1000, 500, "" },//Pistol Flashlight
            { "optic_ACO_grn_smg", "", 2500, 1250, "" }
        };
    };

    class rebel {
        name = "Mohammed's Jihadi Shop";
        side = "civ";
        conditions = "license_civ_rebel";
        items[] = {
            { "vn_ppsh41", "", 25000, 12500, "" },
            { "vn_pps52", "", 30000, 15000, "" },
            { "vn_k50m", "", 50000, 25000, "" },
            { "vn_mat49", "", 20000, 10000, "" },
            { "vn_m3a1", "", 22000, 11000, "" }, //pf
            { "vn_sten", "", 22000, 11000, "" }, //pf
            { "vn_m45", "", 22000, 11000, "" }, //pf
            { "vn_mp40", "", 22000, 11000, "" }, //pf
            { "vn_type56", "", 33000, 16500, "" }, //pf
			{ "vn_m16", "", 33000, 16500, "" }, //pf
			{ "vn_xm177", "", 33000, 16500, "" }, //pf
			{ "vn_xm177_camo", "", 33000, 16500, "" }, //pf
			{ "vn_m14", "", 33000, 16500, "" }, //pf
			{ "vn_m14_camo", "", 33000, 16500, "" }, //pf
			{ "vn_m2carbine", "", 33000, 16500, "" }, //pf
			{ "vn_rpd_shorty", "", 33000, 16500, "" }, //pf
            { "vn_m40a1vn_m40a1", "", 30000, 15000, "" } //pf
        };
        mags[] = {
            { "vn_m14_t_mag", "", 1300, 150, "" },
            { "vn_m16_20_t_mag", "", 1300, 150, "" }, //pf
            { "vn_type56_t_mag", "", 900, 150, "" }, //pf
            { "vn_mp40_t_mag", "", 575, 140, "" }, //pf
            { "vn_m45_t_mag", "", 500, 250, "" }, //pf
            { "vn_sten_t_mag", "", 625, 60, "" }, //pf
			{ "vn_m3a1_t_mag", "", 625, 60, "" }, //pf
			{ "vn_mat49_t_mag", "", 725, 60, "" }, //pf
			{ "vn_ppsh41_35_t_mag", "", 825, 60, "" }, //pf
			{ "vn_ppsh41_71_t_mag", "", 1025, 60, "" }, //pf
			{ "vn_pps_t_mag", "", 125, 60, "" }, //pf
			{ "vn_rpd_100_mag", "", 4025, 60, "" }, //pf
			{ "vn_m40a1_t_mag", "", 125, 60, "" }, //pf
            { "vn_m16_30_t_mag", "", 2025, 60, "" } //pf
        };
        accs[] = {
            { "vn_o_9x_m40a1", "", 23500, 1750, "" },
            { "vn_o_4x_m16", "", 3600, 1800, "" },
            { "vn_o_9x_m16", "", 7500, 3750, "" },
            { "acc_flashlight", "", 1000, 500, "" }
        };
    };

    class gang {
        name = "Hideout Armament";
        side = "civ";
        conditions = "";
        items[] = {
            { "vn_m1carbine", "", 1500, 750, "" },
            { "vn_xm177_short", "", 2500, 1250, "" },
            { "vn_m79_p", "", 4500, 2250, "" },
            { "hgun_PDW2000_F", "", 9500, 4750, "" }
        };
        mags[] = {
            { "vn_40mm_m576_buck_mag", "", 1125, 60, "" },
            { "vn_40mm_m651_cs_mag", "", 1150, 75, "" },
            { "vn_carbine_15_t_mag", "", 1200, 100, "" },
            { "vn_m16_20_t_mag", "", 1250, 125, "" }
        };
        accs[] = {
            { "acc_flashlight_pistol", "", 500, 250, "" },//Pistol Flashlight
            { "optic_ACO_grn_smg", "", 950, 475, "" }
        };
    };

    //Basic Shops
    class genstore {
        name = "Altis General Store";
        side = "civ";
        conditions = "";
        items[] = {
            { "Binocular", "", 150, 75, "" },
            { "ItemGPS", "", 100, 50, "" },
            { "ItemMap", "", 50, 25, "" },
            { "ItemCompass", "", 50, 25, "" },
            { "ItemWatch", "", 50, 25, "" },
            { "FirstAidKit", "", 150, 75, "" },
            { "NVGoggles", "", 2000, 1000, "" },
            { "Chemlight_red", "", 300, 150, "" },
            { "Chemlight_yellow", "", 300, 150, "" },
            { "Chemlight_green", "", 300, 150, "" },
            { "Chemlight_blue", "", 300, 150, "" }
        };
        mags[] = {};
        accs[] = {};
    };

    class f_station_store {
        name = "Altis Fuel Station Store";
        side = "";
        conditions = "";
        items[] = {
            { "Binocular", "", 750, 75, "" },
            { "ItemGPS", "", 500, 50, "" },
            { "ItemMap", "", 250, 25, "" },
            { "ItemCompass", "", 250, 25, "" },
            { "ItemWatch", "", 250, 25, "" },
            { "FirstAidKit", "", 750, 75, "" },
            { "NVGoggles", "", 10000, 1000, "" },
            { "Chemlight_red", "", 1500, 150, "" },
            { "Chemlight_yellow", "", 1500, 150, "" },
            { "Chemlight_green", "", 1500, 150, "" },
            { "Chemlight_blue", "", 1500, 150, "" }
        };
        mags[] = {};
        accs[] = {};
    };

    //Cop Shops
    class cop_basic {
        name = "Altis Cop Shop";
        side = "cop";
        conditions = "";
        items[] = {
            { "Binocular", "", 150, 75, "" }, //pf
            { "ItemGPS", "", 100, 50, "" }, //pf
            { "FirstAidKit", "", 150, 75, "" }, //pf
            { "NVGoggles", "", 2000, 1000, "" }, //pf
            { "HandGrenade_Stone", $STR_W_items_Flashbang, 1700, 850, "" }, //pf
            { "vn_mk22_sd", $STR_W_items_StunPistol, 2000, 1000, "" }, //pf
            { "vn_m1897", $STR_W_items_TaserRifle, 20000, 10000, "" }, //pf
            { "vn_hp", "", 7500, 3750, "" }, //pf
            { "vn_mk22", "", 7500, 3750, "" }, //pf
            { "vn_m1carbine", "", 9500, 4750, "call life_coplevel >= 1" }, //pf
            { "vn_m2carbine", "", 30000, 15000, "call life_coplevel >= 2" }, //pf
            { "vn_m16", "", 35000, 17500, "call life_coplevel >= 2" }, //pf
            { "hgun_ACPC2_F", "", 17500, 8750, "call life_coplevel >= 3" }, //pf
            { "vn_m16_sd", "", 30000, 15000, "call life_coplevel >= 3" }, //pf
            { "gm_g3a4_ebr", "", 32000, 16000, "call life_coplevel >= 3" } //gm
        };
        mags[] = {
            { "vn_mk22_mag", "", 125, 60, "" },
            { "vn_m1897_buck_mag", $STR_W_mags_TaserRifle, 125, 60, "" }, //pf
            { "vn_hp_mag", "", 130, 65, "call life_coplevel >= 1" }, //pf
			{ "vn_carbine_15_mag", "", 130, 65, "call life_coplevel >= 1" }, //pf
            { "vn_carbine_30_mag", "", 130, 65, "call life_coplevel >= 2" }, //pf
            { "vn_m16_20_mag", "", 250, 125, "call life_coplevel >= 2" }, //pf
            { "vn_m16_40_t_mag", "", 200, 100, "call life_coplevel >= 3" }, //pf
            { "gm_20rnd_762x51mm_ap_dm151_g3_des", "", 200, 100, "call life_coplevel >= 3" } //gm
        };
        accs[] = {
            { "muzzle_snds_L", "", 650, 325, "" },
            { "optic_MRD", "", 2750, 1375, "call life_coplevel >= 1" },
            { "acc_flashlight_pistol", "", 250, 125, "call life_coplevel >= 1" },//Pistol Flashlight
            { "acc_flashlight", "", 750, 375, "call life_coplevel >= 2" },
            { "optic_Holosight", "", 1200, 600, "call life_coplevel >= 2" },
            { "optic_Arco", "", 2500, 1250, "call life_coplevel >= 2" },
            { "muzzle_snds_H", "", 2750, 1375, "call life_coplevel >= 2" }
        };
    };

    //Medic Shops
    class med_basic {
        name = "store";
        side = "med";
        conditions = "";
        items[] = {
            { "ItemGPS", "", 100, 50, "" },
            { "Binocular", "", 150, 75, "" },
            { "FirstAidKit", "", 150, 75, "" },
            { "NVGoggles", "", 1200, 600, "" }
        };
        mags[] = {};
        accs[] = {};
    };
};
